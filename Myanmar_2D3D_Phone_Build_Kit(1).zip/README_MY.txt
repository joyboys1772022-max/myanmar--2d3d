Myanmar 2D3D — Phone Build Kit
================================

ဒီ Project သည် Demo/Sandbox သာဖြစ်သည်။ ငွေကြေးလောင်းကြေး၊ ငွေသွင်း/ငွေထုတ်၊ KPay/WavePay API မပါဝင်ပါ။

ဖုန်းတစ်လုံးတည်းဖြင့် APK တည်ဆောက်ရန်:
1. ZIP ကို extract လုပ်ပါ။
2. Chrome မှ https://github.com သို့ဝင်ပြီး account ဝင်ပါ။
3. New repository ဖန်တီးပါ (ဥပမာ myanmar-2d3d)။
4. Add file > Upload files ကိုနှိပ်ပြီး ဒီ folder ထဲက ဖိုင်/ဖိုလ်ဒါအားလုံးကို upload လုပ်ပါ။
   အထူးသဖြင့် .github folder ကိုပါ upload လုပ်ပါ။
5. Commit changes လုပ်ပါ။
6. Repository > Actions ကိုဖွင့်ပါ။
7. "Build Myanmar 2D3D APK" workflow ကိုရွေးပြီး Run workflow ကိုနှိပ်ပါ။
8. အစိမ်းရောင်အောင်မြင်မှုရလာလျှင် workflow run ကိုဖွင့်ပါ။
9. Artifacts အောက်ရှိ Myanmar-2D3D-debug-APK ကို Download လုပ်ပြီး ZIP ဖြည်ပါ။
10. app-debug.apk ကို Android ဖုန်းတွင်ဖွင့်၍ install လုပ်ပါ။ Unknown apps install ခွင့်ကို Android Settings မှ ခွင့်ပြုရန်လိုနိုင်သည်။

Demo Login:
User: 09123456789 / demo1234
Admin: 09987654321 / admin1234
Admin 2: 09444444444 / admin1234

မှတ်ချက်:
- GitHub Cloud Build က APK ကိုတည်ဆောက်ပေးသည်။ ChatGPT ထဲမှ တိုက်ရိုက် Android SDK compile လုပ်ခြင်းမဟုတ်ပါ။
- Debug APK သည် စမ်းသပ်ရန်သာဖြစ်ပြီး Play Store production release မဟုတ်ပါ။
- Login သည် local demo credential သာဖြစ်သည်။ Server/database မရှိသဖြင့် production လုံခြုံရေးအတွက် မသုံးပါနှင့်။
